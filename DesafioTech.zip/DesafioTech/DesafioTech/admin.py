from django.contrib import admin
from DesafioTech.models import User

class Users(admin.ModelAdmin):
    
    list_display = ('id', 'username', 'email', 'password', 'birthday')
    list_display_links = ('id', 'username')
    search_fields = ('username', )

admin.site.register(User, Users)
