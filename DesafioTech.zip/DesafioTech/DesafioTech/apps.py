from django.apps import AppConfig


class DesafiotechConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'DesafioTech'
