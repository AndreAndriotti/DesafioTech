from rest_framework import serializers
from DesafioTech.models import User
#from django.contrib.auth.models.User import objects

class UserSerializer(serializers.ModelSerializer):   

    password = serializers.CharField(style={'input_type': 'password'}, allow_blank=True, write_only=True)
    birthday = serializers.DateField()
    
    class Meta:
        model = User
        fields = ('username', 'email', 'password', 'birthday',)
        
        if model.password == "":
            password = User.objects.make_random_password()
            model.set_password(password)
            model.save()
