from rest_framework import viewsets
from rest_framework import filters
from DesafioTech.models import User
from DesafioTech.serializer import UserSerializer
import csv

class UsersViewSet(viewsets.ModelViewSet):

    search_fields = ['username']
    filter_backends = (filters.SearchFilter,)
    queryset = User.objects.all()
    serializer_class = UserSerializer
